### tree-sitter-objcpp
Based on
- [tree-sitter-cpp](https://github.com/tree-sitter/tree-sitter-cpp): [v0.23.4](https://github.com/tree-sitter/tree-sitter-cpp/releases/tag/v0.23.4)
- [tree-sitter-objc](https://github.com/BenArvin/tree-sitter-objcpp#): [v3.0.2](https://github.com/BenArvin/tree-sitter-objcpp/releases/tag/v3.0.2)

Requirements
- python-tree-sitter: >= 0.24.0

Use in project
```
pip install grammar/UNKNOWN-0.0.0-cp39-abi3-macosx_10_9_x86_64.whl

```